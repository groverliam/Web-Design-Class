 <html xmlns="http://www.w3.org/1999/xhtml">

<head>
	<title>Add Goods</title>
	<link rel="stylesheet" href="includes/admin.css" type="text/css" media="screen" />
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
</head>
<body>
<?php
	include("includes/header_staff.html");
	
	if ($_SERVER['REQUEST_METHOD']=='POST'){		
		//retrieve form data
		$error = array();
		
		if (!empty($_POST['orderID']))
			$orderID = $_POST['orderID'];
		else 
			$error[] = "Please enter order ID.";
		if (!empty($_POST['productID']))
			$productID = $_POST['productID'];
		else 
			$error[] = "Please enter product ID.";
			
		if (!empty($_POST['unitPrice']))
			$unitPrice = $_POST['unitPrice'];
		else 
			$error[] = "Please enter unit price.";
			
		if (!empty($_POST['quantity']))
			$quantity = $_POST['quantity'];
		else 
			$error[] = "Please enter the quantity.";
			

		if(!empty($error)){
			foreach ($error as $msg){
				echo $msg;
				echo '<br>';
			}
		}
		else {
			include ("includes/db_connection.php");

			// sql to insert data to table
			$sql = "INSERT INTO orders (orderID, productID, unitPrice, quantity, status)
					VALUES ('$orderID', '$productID', '$unitPrice', '$quantity', 'processing')";

			if ($conn->query($sql) === TRUE) {
    			echo "New record created successfully";
			} else {
    			echo "Error: " . $sql . "<br>" . $conn->error;
			}

			$conn->close();	
		}
	}
?>
<br><br><br>
<h1>Please Fill Out Form</h1>

<form action="" method="post">
	<table>
		<tr>
			<td>Order ID: </td>
			<td><input type="text" name="orderID" 
				value=<?php if(isset($_POST['orderID'])) echo $_POST['orderID'] ?>></td>
		</tr>
		<tr>
			<td>Product ID: </td>
			<td><input type="text" name="productID" 
				value=<?php if(isset($_POST['productID'])) echo $_POST['productID'] ?>></td>
		</tr>
		<tr>
			<td>Unit Price: </td>
			<td><input type="text" name="unitPrice" 
				value=<?php if(isset($_POST['unitPrice'])) echo $_POST['unitPrice'] ?>></td>
		</tr>
		<tr>
			<td>Quantity: </td>
			<td><input type="text" name="quantity" 
				value=<?php if(isset($_POST['quantity'])) echo $_POST['quantity'] ?>></td>
		</tr>
		
		
		
	</table>
	<input type="Submit">
</form>

</body>
</html>