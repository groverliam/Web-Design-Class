<?php
			$servername = "localhost";
			$username = "s1004312";
			$password = "thai0Oyi";
			$dbname = "s1004312";
			//create connection
			$conn = new mysqli($servername, $username, $password, $dbname);

			//check connection
			if ($conn->connect_error) {
    			//die("Connection failed: " . $conn->connect_error);
			} 
?>
	
	
